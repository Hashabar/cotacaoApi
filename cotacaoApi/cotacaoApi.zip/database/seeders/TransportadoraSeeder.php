<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TransportadoraSeeder extends Seeder
{
    static $transportadora = [
        'Patrus',
        'Alfa',
        'Expresso'
    ];
    private static $order = 1;
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        foreach (self::$transportadora as $transportadora) {
            DB::table('transportadora')->insert([
                'id' => self::$order++,
                'nome' => $transportadora
            ]);
        }
    }
}
