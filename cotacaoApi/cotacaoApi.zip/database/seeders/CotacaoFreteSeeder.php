<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CotacaoFreteSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('cotacao_frete')->insert([
            'uf' => 'PR',
            'percentual_cotacao' => 2.5,
            'valor_extra' => 3.3,
            'transportadora_id' => 1
        ]);
    }
}
