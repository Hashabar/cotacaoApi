<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Cotacao</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="app.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container-fluid" style="width: fit-content;">
        <div class="mt-5 mb-3 clearfix">
            <h2 class="pull-left">Cotar Frete</h2>
        </div>
        <form action="{{ route('cotar_frete')}}" method="POST">
            @csrf
            <div class="campoTexto">
                <label>UF</label>
                <input type="text" name="uf2" class="form-control">
                @if($errors->has('uf2'))
                <div class="error">{{ $errors->first('uf2') }}</div>
                @endif
            </div>
            <div class="campoTexto">
                <label>Valor do Produto</label>
                <input type="text" name="valor_pedido" class="form-control">
                @if($errors->has('valor_pedido'))
                <div class="error">{{ $errors->first('valor_pedido') }}</div>
                @endif
            </div>

            <button>Salvar</button>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="mt-5 mb-3 clearfix">
                            <h2 class="pull-left">Melhores resultados</h2>
                        </div>
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Rank</th>
                                    <th>Transportadora</th>
                                    <th>Valor cotação($)</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($cotacao as $key => $data)
                                <tr>
                                    <th>{{$data->transportadora_id}}</th>
                                    <th>{{$data->uf}}</th>
                                    <th>{{$data->percentual_cotacao}}</th>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <div class="wrapper">
        <div class="container-fluid" style="width: fit-content;">
            <div class="mt-5 mb-3 clearfix">
                <h2 class="pull-left">Cadastro Cotação de Frete</h2>
            </div>
            <form action="{{ route('postCotar')}}" method="POST">
                @csrf
                <div class="campoTexto">
                    <label>Transportadora</label>
                    <input type="text" name="transportadora_id" class="form-control">
                    @if($errors->has('transportadora_id'))
                    <div class="error">{{ $errors->first('transportadora_id') }}</div>
                    @endif
                </div>
                <div class="campoTexto">
                    <label>UF</label>
                    <input type="text" name="uf" class="form-control">
                    @if($errors->has('uf'))
                    <div class="error">{{ $errors->first('uf') }}</div>
                    @endif
                </div>
                <div class="campoTexto">
                    <label>Percentual Cotação</label>
                    <input type="text" name="percentual_cotacao" class="form-control">
                    @if($errors->has('percentual_cotacao'))
                    <div class="error">{{ $errors->first('percentual_cotacao') }}</div>
                    @endif
                </div>
                <div class="campoTexto">
                    <label>Valor Extra</label>
                    <input type="text" name="valor_extra" class="form-control">
                    @if($errors->has('valor_extra'))
                    <div class="error">{{ $errors->first('valor_extra') }}</div>
                    @endif
                </div>
                <button>Salvar</button>
            </form>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="mt-5 mb-3 clearfix">
                        <h2 class="pull-left">Lista de Imposto</h2>
                    </div>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Id Transportadora</th>
                                <th>Uf</th>
                                <th>Percentual Cotação(%)</th>
                                <th>Valor Extra($)</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($cotacao as $key => $data)
                            <tr>
                                <th>{{$data->transportadora_id}}</th>
                                <th>{{$data->uf}}</th>
                                <th>{{$data->percentual_cotacao}}</th>
                                <th>{{$data->valor_extra}}</th>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>

</html>