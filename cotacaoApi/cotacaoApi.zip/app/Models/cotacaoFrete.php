<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class cotacaoFrete extends Model
{
    public $timestamps = false;
    protected $table = "cotacao_frete";
    protected $fillable = ['id', 'uf', 'percentual_cotacao', 'valor_extra', 'transportadora_id'];
}
