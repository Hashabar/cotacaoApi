<?php

namespace App\Http\Controllers;

use App\Models\transportadora;
use App\Http\Requests\StoretransportadoraRequest;
use App\Http\Requests\UpdatetransportadoraRequest;

class TransportadoraController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $transportadora = transportadora::with('transportadora')->get();
        return response()->json($transportadora);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoretransportadoraRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoretransportadoraRequest $request)
    {
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\transportadora  $transportadora
     * @return \Illuminate\Http\Response
     */
    public function show(transportadora $transportadora)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\transportadora  $transportadora
     * @return \Illuminate\Http\Response
     */
    public function edit(transportadora $transportadora)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdatetransportadoraRequest  $request
     * @param  \App\Models\transportadora  $transportadora
     * @return \Illuminate\Http\Response
     */
    public function update(UpdatetransportadoraRequest $request, transportadora $transportadora)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\transportadora  $transportadora
     * @return \Illuminate\Http\Response
     */
    public function destroy(transportadora $transportadora)
    {
        //
    }
}
