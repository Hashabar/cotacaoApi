<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Validator;
use App\Models\cotacaoFrete;
use App\Http\Requests\StorecotacaoFreteRequest;
use App\Http\Requests\UpdatecotacaoFreteRequest;

class CotacaoFreteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $cotacaoFrete = cotacaoFrete::with('cotacao_frete')->get();
        return response()->json($cotacaoFrete);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StorecotacaoFreteRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StorecotacaoFreteRequest $request)
    {

        $validator = Validator::make($request->all(), [
            'uf' => 'required|max:2|unique:App\Models\cotacaoFrete,uf',
            'percentual_cotacao' => 'required|integer|min:0',
            'valor_extra' => 'required|integer|min:0',
            'transportadora_id' => 'required|integer|unique:App\Models\cotacaoFrete,transportadora_id',
        ]);
        if ($validator->fails()) {
            $errors = $validator->errors();

            return response()->json($errors, 500);
        }

        $cotacaoFrete = new cotacaoFrete();
        $cotacaoFrete->fill($request->all());
        $cotacaoFrete->save();
        if ($cotacaoFrete === false) {
            return response()->json('Erro ao gravar cotaçao!', 500);
        }

        return response()->json('Sucesso', 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\cotacaoFrete  $cotacaoFrete
     * @return \Illuminate\Http\Response
     */
    public function show(cotacaoFrete $cotacaoFrete)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\cotacaoFrete  $cotacaoFrete
     * @return \Illuminate\Http\Response
     */
    public function edit(cotacaoFrete $cotacaoFrete)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdatecotacaoFreteRequest  $request
     * @param  \App\Models\cotacaoFrete  $cotacaoFrete
     * @return \Illuminate\Http\Response
     */
    public function update(UpdatecotacaoFreteRequest $request, cotacaoFrete $cotacaoFrete)
    {
        $validator = Validator::make($request->all(), [
            'uf' => 'required|max:2',
            'valor_pedido' => 'required|integer|min:0',
        ]);
        if ($validator->fails()) {
            $errors = $validator->errors();
            return response()->json($errors, 500);
        }
        $listaGet = cotacaoFrete::all();
        $listaGet = json_decode($listaGet, true);

        foreach ($listaGet as $lista) {
            if (in_array($request['uf'], $lista)) {
                $i = 1;
                $retorno = ($request['valor_pedido'] / 100 * $lista['percentual_cotacao']) + $lista['valor_extra'];
                $melhorResultado = [$lista['transportadora_id'], $retorno];
                $retornoRank[$i] = [$melhorResultado];
                $i++;
                sort($retornoRank);
                $cotacao = count($retornoRank);

                if ($cotacao === 3) {
                    break;
                }
            }
        }
        if (!empty($retornoRank)) {
            return response()->json($retornoRank, 200);
        }

        return response()->json('Cotacao nao cadastrada o UF!', 500);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\cotacaoFrete  $cotacaoFrete
     * @return \Illuminate\Http\Response
     */
    public function destroy(cotacaoFrete $cotacaoFrete)
    {
        //
    }
}
