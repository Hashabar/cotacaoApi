<?php

use App\Http\Controllers\CotacaoFreteController;
use App\Models\cotacaoFrete;
use App\Models\transportadora;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::get('transportadora', function () {
    // If the Content-Type and Accept headers are set to 'application/json', 
    // this will return a JSON structure. This will be cleaned up later.
    return transportadora::all();
});

Route::get('cotacao', function () {
    // If the Content-Type and Accept headers are set to 'application/json', 
    // this will return a JSON structure. This will be cleaned up later.
    return cotacaoFrete::all();
});

// Route::post('cotacao', function () {
//     // If the Content-Type and Accept headers are set to 'application/json', 
//     // this will return a JSON structure. This will be cleaned up later.
//     return [CotacaoFreteController::class, 'store'];
// });

Route::post('cotacao', [CotacaoFreteController::class, 'store']);

Route::put('cotacao', [CotacaoFreteController::class, 'update']);
